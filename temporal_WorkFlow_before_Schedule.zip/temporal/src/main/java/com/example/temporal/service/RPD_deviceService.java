package com.example.temporal.service;


import com.example.temporal.model.DTO.DeviceDTO;
import com.example.temporal.model.RPD_deviceModel;
import com.example.temporal.model.ScannerModel;
import com.example.temporal.repo.RPD_deviceModelRepo;
import com.example.temporal.repo.ScannerRepo;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class RPD_deviceService {

    @Autowired
    RPD_deviceModelRepo rpdDeviceRepo;

    @Autowired
    ScannerRepo scannerRepo;

//    public void addDevice(RPD_deviceModel obj) throws Exception {
//        {
//            Optional<RPD_deviceModel> user = rpdDeviceRepo.findByMac(obj.getName());
//            if (user.isPresent()) {
//                throw new Exception("Device already exists with this Name");
//            }
//            rpdDeviceRepo.save(obj);
//        }
//    }

    public void addDevice(DeviceDTO deviceDTO) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        String mac=deviceDTO.getMacAddress();
        String serial=deviceDTO.getSerialNumber();
        boolean flag=false;
        try {
            File file = new ClassPathResource("devices.json").getFile();
            // Read JSON file into a List of Device objects
            List<RPD_deviceModel> devices = objectMapper.readValue(file, new TypeReference<List<RPD_deviceModel>>() {});
            // Now you can process the list of devices as needed
            System.out.println(mac+" "+serial);////////////////
            for (RPD_deviceModel device : devices) {
                System.out.println("MAC: " + device.getMac() + ", Serial Number: " + device.getSerialNumber());//////////////
                // Save the rest of the device data or perform other operations
                System.out.println(mac.equals(device.getMac()));
                if (mac.equals(device.getMac()) && serial.equals(device.getSerialNumber())) {
                    flag = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(!flag){
            throw new Exception("Mac and Serial Number not matching!");
        }
        Optional<RPD_deviceModel> user = rpdDeviceRepo.findByMac(mac);
        if (user.isPresent()) {
            RPD_deviceModel userObj=user.get();
            userObj.setAssigned_ip("x");
            userObj.setName(deviceDTO.getName());
            userObj.setGateway("x");
            userObj.setModel(deviceDTO.getModel());
            userObj.setStatus("x");
            userObj.setSubnet("x");
            userObj.setDiscoveryMode("x");
            userObj.setVersion("x");
            userObj.setVendor(deviceDTO.getManufacturer());
            rpdDeviceRepo.save(userObj);
//                throw new Exception("Device already exists with this Name");
        }
        else {
            RPD_deviceModel obj=new RPD_deviceModel(deviceDTO.getName(),deviceDTO.getMacAddress(),deviceDTO.getSerialNumber(),deviceDTO.getManufacturer(),deviceDTO.getModel());
            rpdDeviceRepo.save(obj);
        }
    }

    public RPD_deviceModel getDevice(String mac) throws Exception {
        Optional<RPD_deviceModel> user = rpdDeviceRepo.findByMac(mac);
        System.out.println(mac);
        if (!user.isPresent()) {
            throw new Exception("Device with this mac does not exist");
        }

        return user.get();
    }
    public boolean mobileScanner(long siteId,String mac) {
        System.out.println("In Mobile Scanner");
        //check if mac id is present and return
        try {
            RPD_deviceModel rpdDeviceModel = getDevice(mac);
            //save to a new table(id,lat,lon,mac?)
            //ScannerModel scannerModel=new ScannerModel(siteId,mac);
            //scannerRepo.save(scannerModel);

        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
            //when device not present with given mac
            return false;
        }
        System.out.println("id and mac saved");
        return true;
    }

    public void addScannerDetail(ScannerModel obj){
        {
            scannerRepo.save(obj);
        }
    }



}
