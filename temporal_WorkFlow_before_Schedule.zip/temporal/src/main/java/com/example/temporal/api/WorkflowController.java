package com.example.temporal.api;

import io.grpc.StatusRuntimeException;
import io.temporal.api.workflowservice.v1.*;
import io.temporal.serviceclient.WorkflowServiceStubs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/workflow")
public class WorkflowController {

    @Autowired
    private WorkflowServiceStubs workflowServiceStubs;

    @GetMapping("/open-executions")
    public ResponseEntity<?> listOpenWorkflowExecutions() {
        try {
            ListOpenWorkflowExecutionsRequest listRequest = ListOpenWorkflowExecutionsRequest.newBuilder()
                    .setNamespace("default") // Set your namespace here
                    .build();
            //System.out.println(workflowServiceStubs.blockingStub().listOpenWorkflowExecutions(listRequest));
            return ResponseEntity.ok(workflowServiceStubs.blockingStub().listOpenWorkflowExecutions(listRequest).toString());
        } catch (StatusRuntimeException e) {
            // Handle the exception appropriately, e.g., log the error
            e.printStackTrace();
            return null;
        }
    }

    @GetMapping("/closed-executions")
    public ResponseEntity<?> listClosedWorkflowExecutions() {
        try {
            ListClosedWorkflowExecutionsRequest listRequest = ListClosedWorkflowExecutionsRequest.newBuilder()
                    .setNamespace("default")
                    .build();
            ListClosedWorkflowExecutionsResponse response = workflowServiceStubs.blockingStub().listClosedWorkflowExecutions(listRequest);
            return ResponseEntity.ok(response.toString());
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to list closed workflow executions");
        }
    }

    @GetMapping("/executions")
    public ResponseEntity<?> listWorkflowExecutions() {
        try {
            ListWorkflowExecutionsRequest listRequest = ListWorkflowExecutionsRequest.newBuilder()
                    .setNamespace("default")
                    .build();
            ListWorkflowExecutionsResponse response = workflowServiceStubs.blockingStub().listWorkflowExecutions(listRequest);
            return ResponseEntity.ok(response.toString());
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to list workflow executions");
        }
    }


    @GetMapping("/describe-executions")
    public ResponseEntity<?> describeWorkflowExecution(@RequestBody Map<String,String> input) {
        try {
            // Assuming you have the workflowId and runId defined somewhere in your application
            String workflowId = input.get("workflowId");
            String runId = input.get("runId");

            DescribeWorkflowExecutionRequest request = DescribeWorkflowExecutionRequest.newBuilder()
                    .setNamespace("default")
                    .setExecution(
                            io.temporal.api.common.v1.WorkflowExecution.newBuilder()
                                    .setWorkflowId(workflowId)
                                    .setRunId(runId)
                                    .build()
                    )
                    .build();

            DescribeWorkflowExecutionResponse response = workflowServiceStubs.blockingStub().describeWorkflowExecution(request);
            return ResponseEntity.ok(response.toString());
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to describe workflow executions");
        }
    }



}
